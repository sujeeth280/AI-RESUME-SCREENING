export default function Loading() {

  return (
    <div className="loading-card">

      <div className="loading-orbit">
        <div />
      </div>

      <div>
        <h3>
          AI is screening the candidate
        </h3>

        <p>
          Reading resume, comparing skills,
          calculating experience and generating
          the match score...
        </p>
      </div>

    </div>
  );
}